<?php
include 'functions.php';
// Your PHP code here.

// Home Page template below.
?>

<?=template_header('Web Travel')?>

<div class="content">
	<h2>Web Travel</h2>
	<p>Book Your Trip</p>
</div>

<?=template_footer()?>