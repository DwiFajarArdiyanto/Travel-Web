<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>package</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">travel.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="read.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/1.jpg" alt="">
         </div>
         <div class="content">
            <h3>Pulau Merah</h3>
            <p>Pantai Banyuwangi di daerah selatan yang paling menawan</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/2.jpg" alt="">
         </div>
         <div class="content">
            <h3>Kawah Ijen</h3>
            <p>Api Biru menjadi salah satu daya tarik utama dari Kawah ijen</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/3.jpg" alt="">
         </div>
         <div class="content">
            <h3>De Djawata</h3>
            <p>Wisata yang sejatinya merupakan kawasan hutan lindung milik perhutani</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/4.jpg" alt="">
         </div>
         <div class="content">
            <h3>Pantai mustika</h3>
            <p>Pantai Mustika terletak diantara Pulau Merah dan Pantai Pancer</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/5.jpg" alt="">
         </div>
         <div class="content">
            <h3>gunung ranti</h3>
            <p>Gunung Ranti atau disebut sebagai negeri di atas awan</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/6.jpg" alt="">
         </div>
         <div class="content">
            <h3>air terjun jagir</h3>
            <p>Air Terjun Jagir memiliki pesona yang tidak ditemukan di air terjun lainnya</p>
            <a href="index.php" class="btn">book now</a>
         </div>
      </div>

   </div>
</section>

<section class="footer">

   <div class="box-container">

   <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="index.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> 083456786543 </a>
         <a href="#"> <i class="fas fa-phone"></i> 082345765432 </a>
         <a href="#"> <i class="fas fa-envelope"></i> ardi@fajar.com </a>
         <a href="#"> <i class="fas fa-map"></i> Malang, Jawa Timur, Indonesia </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Dwi Fajar Ardiyanto</span> | all rights reserved! </div>

</section>

<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

</body>
</html>